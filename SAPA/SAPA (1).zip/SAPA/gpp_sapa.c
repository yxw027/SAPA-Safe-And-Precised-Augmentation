#include "gpp_sapa.h"
#include "bit2buff.h"
GPPLONG gpp_sapa_ocb2buffer(const pGPP_SAPA_OCB p_ocb, GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos)
{
	GPPUINT1 o_flag=0;
	GPPUINT1 c_flag = 0;
	GPPUINT1 b_flag = 0;
	for (int i = 0; i < 1; i++)//GPP_SAPA_MAX_CONS
	{
		printf("value%d\n", p_ocb->header_block[i]->message_sub_type);
		gn_add_long_to_buffer(buffer, &byte_pos, &bit_pos, 4, 1); //SF001 p_ocb->header_block[i]->message_sub_type
		printf("buffer%d\n", *buffer);
		printf("byte pos%d\n", byte_pos);
		printf("bit pos%d\n", bit_pos);
		gpp_add_header2buffer(buffer, byte_pos, bit_pos, i, 0, p_ocb->header_block[i]->time_tag_type, p_ocb->header_block[i]->time_tag, p_ocb->header_block[i]->system_id,
			p_ocb->header_block[i]->system_processor_id, p_ocb->header_block[i]->sol_issue_of_update, p_ocb->header_block[i]->end_of_obc_set, p_ocb->header_block[i]->yaw_flag, p_ocb->header_block[i]->sat_ref_datum,
			p_ocb->header_block[i]->ephemeris_type);
		if (p_ocb->sv_prn_bits[i] == 0) continue;

		for (int j = 0; j < GPP_SAPA_MAX_SAT; j++)
		{
			if (gpp_sapa_get_satellite_present_bit(p_ocb->sv_prn_bits[i], j) == 0)continue;

			if (p_ocb->header_block[i]->message_sub_type == 0)//GPS
			{
				gpp_add_sv2buffer(buffer, byte_pos, bit_pos, i, j, p_ocb->sv_prn_bits[i], p_ocb->sv[i][j]->do_not_use, p_ocb->sv[i][j]->ocb_present_flag, p_ocb->sv[i][j]->clk->iode_continuity, 0, 0, 0, 32, 44, 56, 64);
				if (o_flag == 1)
				{
					gpp_add_orbit2buffer(buffer, byte_pos, bit_pos, i, j, p_ocb->sv[i][j]->orb->iode, p_ocb->sv[i][j]->orb->orbit_radial_correction, p_ocb->sv[i][j]->orb->orbit_along_track_correction, p_ocb->header_block[i]->yaw_flag,
						p_ocb->sv[i][j]->orb->orbit_cross_track_correction, p_ocb->sv[i][j]->orb->satellite_yaw, 8);
				}
				if (c_flag == 1)
				{
					gpp_add_clock2buffer(buffer, byte_pos, bit_pos, i, j, p_ocb->sv[i][j]->clk->iode_continuity, p_ocb->sv[i][j]->clk->clock_correction, p_ocb->sv[i][j]->clk->clock_correction);
				}
				if (b_flag == 1)
				{
					GPPUINT4 max_sig = gpp_add_phase_bias_mask2buffer(buffer, byte_pos, bit_pos, i, j, p_ocb->sv[i][j]->bias->pb_sig_bits, 6, 11);
					for (int k = 0; k < max_sig; k++)
					{
						gpp_add_phasebias2buffer(buffer, byte_pos, bit_pos, i, j, p_ocb->sv[i][j]->bias->phase_bias[k]->fix_flag, p_ocb->sv[i][j]->clk->iode_continuity, p_ocb->sv[i][j]->bias->phase_bias[k]->phase_bias_correction);
					}
					GPPUINT4 max_sng = gpp_add_code_bias_mask2buffer(buffer, byte_pos, bit_pos, i, j, p_ocb->sv[i][j]->bias->pb_sig_bits, 6, 11);
					for (int k = 0; k < max_sng; k++)
					{
						gpp_add_codebiasbuffer(buffer, byte_pos, bit_pos, i, j, p_ocb->sv[i][j]->bias->code_bias[k]->code_bias_correction);
					}
				}
			}
			else if (p_ocb->header_block[i]->message_sub_type == 1)//GLONASS
			{
				gpp_add_sv2buffer(buffer, byte_pos, bit_pos, i, j, p_ocb->sv_prn_bits[i], p_ocb->sv[i][j]->do_not_use, p_ocb->sv[i][j]->ocb_present_flag, p_ocb->sv[i][j]->clk->iode_continuity, 0, 0, 0, 24, 36, 48, 63);
				if (o_flag == 1)
				{
					gpp_add_orbit2buffer(buffer, byte_pos, bit_pos, i, j, p_ocb->sv[i][j]->orb->iode, p_ocb->sv[i][j]->orb->orbit_radial_correction, p_ocb->sv[i][j]->orb->orbit_along_track_correction, p_ocb->header_block[i]->yaw_flag,
						p_ocb->sv[i][j]->orb->orbit_cross_track_correction, p_ocb->sv[i][j]->orb->satellite_yaw, 7);
				}
				if (c_flag == 1)
				{
					gpp_add_clock2buffer(buffer, byte_pos, bit_pos, i, j, p_ocb->sv[i][j]->clk->iode_continuity, p_ocb->sv[i][j]->clk->clock_correction, p_ocb->sv[i][j]->clk->clock_correction);
				}
				if (b_flag == 1)
				{
					GPPUINT4 max_sig = gpp_add_phase_bias_mask2buffer(buffer, byte_pos, bit_pos, i, j, p_ocb->sv[i][j]->bias->pb_sig_bits, 5, 9);
					for (int k = 0; k < max_sig; k++)
					{
						gpp_add_phasebias2buffer(buffer, byte_pos, bit_pos, i, j, p_ocb->sv[i][j]->bias->phase_bias[k]->fix_flag, p_ocb->sv[i][j]->clk->iode_continuity, p_ocb->sv[i][j]->bias->phase_bias[k]->phase_bias_correction);
					}
					GPPUINT4 max_sng = gpp_add_code_bias_mask2buffer(buffer, byte_pos, bit_pos, i, j, p_ocb->sv[i][j]->bias->pb_sig_bits, 5, 9);
					for (int k = 0; k < max_sng; k++)
					{
						gpp_add_codebiasbuffer(buffer, byte_pos, bit_pos, i, j, p_ocb->sv[i][j]->bias->code_bias[k]->code_bias_correction);
					}
				}
			}
		}
	}
	return 0;
}
GPPLONG gpp_sapa_buffer2ocb(pGPP_SAPA_OCB ocb, const GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos)
{

}
GPPLONG gpp_sapa_hpac2buffer(const pGPP_SAPA_HPAC hpac, GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos)
{

}
GPPLONG gpp_sapa_buffer2hpac(pGPP_SAPA_HPAC hpac, const GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos)
{

}
GPPLONG gpp_sapa_area2buffer(const pGPP_SAPA_AREA area, GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos)
{

}
GPPLONG gpp_sapa_buffer2area(pGPP_SAPA_AREA area, const GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos)
{

}

//Returns 1 if a bit at position pos in prnbits is set else return 0
GPPUINT1 gpp_sapa_get_satellite_present_bit(GPPUINT8 prn_bits, GPPUINT1 pos)
{
	GPPINT8 base = 1;
	return (prn_bits & (base << pos)) ? 1 : 0;
}

//Return Seconds passed in the hour when data is received.
GPPINT gpp_sapa_get_hourly_time_tag(GPPINT seconds_of_week)
{
	return(seconds_of_week % 3600);
}

//Returns seconds passed since the beginning including all gps_weeks.
GPPINT gpp_sapa_get_full_time_tag(GPPINT gps_week, GPPINT seconds_of_week)
{
	return(((gps_week - 1) * 7 * 24 * 3600) + seconds_of_week);    
}

// combines the flag values such that Orbit flag is on left most position followed by Clock and Bias Flags respectively
GPPUINT1 gpp_sapa_get_ocb_present_flags(GPPINT1 o_flag, GPPUINT1 c_flag, GPPUINT1 b_flag)
{
	return((o_flag << 2) | (c_flag << 1) | b_flag);       
}

//Returns Orbit ,Clock and  Bias flag value
void gpp_sapa_get_ocb_flag_value(GPPUINT1 ocb_present_flag, const GPPUINT1 *o_flag, const GPPUINT1 *c_flag, const GPPUINT1 *b_flag)
{
	o_flag = (ocb_present_flag & (1 << 2)) ? 1 : 0;
	c_flag = (ocb_present_flag & (1 << 1)) ? 1 : 0;
	b_flag = (ocb_present_flag & (1 << 0)) ? 1 : 0;
}
//Returns highest order of satellite set
GPPUINT1 gpp_sapa_get_max_sat_id(GPPUINT8 sat_mask)
{
	GPPUINT1 max_sat_id = 0;
	for (GPPUINT1 sat_id = 0; sat_id < 64; sat_id++)
	{
		if ((sat_mask >> sat_id) & 1)
		{
			max_sat_id = sat_id;
		}
	}
	return(max_sat_id);
}

//Returns highest order of bias mask set
GPPUINT1 gpp_sapa_get_max_bias_id(GPPUINT2 bias_mask)
{
	GPPUINT1 max_bias_id = 0;
	for (GPPUINT1 bias_id = 0; bias_id < 12; bias_id++)
	{
		if ((bias_mask >> bias_id) & 1)
		{
			max_bias_id = bias_id;
		}
	}
	return(max_bias_id);
}
//Sets satellite mask position
GPPUINT8 gpp_sapa_set_satellite_mask_position(GPPUINT8 sat_mask, GPPUINT1 sat_pos)
{
	sat_mask = ((1 << sat_pos) | sat_mask);
	return sat_mask;
}
//Sets Bias mask position
GPPUINT2 gpp_sapa_set_bias_mask_position(GPPUINT2 bias_mask, GPPUINT1 bias_pos)
{
	bias_mask = ((1 << bias_pos) | bias_mask);
	return bias_mask;
}

//=============================================== functions to add data to structure =================================================
	
//stores data to GPP_SAPA_HEADER_BLOCK structure
void gpp_add_header_data2structure(pGPP_SAPA_OCB ocb, GPPUINT1 header_index, GPPUINT1 msg_subtype, GPPUINT1 timetag_type, GPPDOUBLE timetag, GPPUINT4 sys_id, GPPUINT4 sys_processor_id, GPPUINT4 sol_iou, GPPUINT1 end_of_ocb_set, GPPUINT1 yawflag, GPPUINT1 sat_reference_datum, GPPUINT1 ephemeristype)
{

	ocb->header_block[header_index]->message_sub_type = msg_subtype;
	printf("message sub type = %d", ocb->header_block[0]->message_sub_type);

	ocb->header_block[header_index]->time_tag_type = timetag_type;
	printf("time tag type = %d", ocb->header_block[0]->time_tag_type);

	ocb->header_block[header_index]->time_tag = timetag;
	printf("time_tag = %d", ocb->header_block[0]->yaw_flag);

	ocb->header_block[header_index]->system_id = sys_id;
	printf("system_id = %d", ocb->header_block[0]->system_id);

	ocb->header_block[header_index]->system_processor_id = sys_processor_id;
	printf("system_processor_id = %d", ocb->header_block[0]->system_processor_id); 

	ocb->header_block[header_index]->sol_issue_of_update = sol_iou;
	printf("sol_issue_of_update = %d", ocb->header_block[0]->sol_issue_of_update);

	ocb->header_block[header_index]->end_of_obc_set = end_of_ocb_set;
	printf("end of ocb = %d", ocb->header_block[0]->end_of_obc_set);

	ocb->header_block[header_index]->yaw_flag = yawflag;
	printf("yaw_flag = %d", ocb->header_block[0]->yaw_flag);

	ocb->header_block[header_index]->sat_ref_datum = sat_reference_datum;
	printf("sat_ref_datum = %d", ocb->header_block[0]->sat_ref_datum);

	ocb->header_block[header_index]->ephemeris_type = ephemeristype;
	printf("ephemeris_type = %d", ocb->header_block[0]->ephemeris_type);
}

//stores data to GPP_SAPA_OCB_SV_ORBIT structure
void gpp_add_orbit_data2structure(pGPP_SAPA_OCB ocb, GPPUINT1 cons_index, GPPUINT1 sat_index, GPPUINT4 iode, GPPDOUBLE orb_radial_corr, GPPDOUBLE orb_along_track_corr, GPPDOUBLE orb_cross_track_corr, GPPDOUBLE sat_yaw)
{
	ocb->sv[cons_index][sat_index]->orb->iode = iode;
	ocb->sv[cons_index][sat_index]->orb->orbit_radial_correction = orb_radial_corr;
	ocb->sv[cons_index][sat_index]->orb->orbit_along_track_correction = orb_along_track_corr;
	ocb->sv[cons_index][sat_index]->orb->orbit_cross_track_correction = orb_cross_track_corr;
	ocb->sv[cons_index][sat_index]->orb->satellite_yaw = sat_yaw;

}

//stores data to GPP_SAPA_OCB_SV_CLOCK structure
void gpp_add_clock_data2structure(pGPP_SAPA_OCB ocb, GPPUINT1 cons_index, GPPUINT1 sat_index, GPPDOUBLE iode_continuity, GPPDOUBLE clk_corr, GPPDOUBLE user_range_err)
{
	ocb->sv[cons_index][sat_index]->clk->iode_continuity = iode_continuity;
	ocb->sv[cons_index][sat_index]->clk->clock_correction = clk_corr;
	ocb->sv[cons_index][sat_index]->clk->user_range_error = user_range_err;
}

//stores data to GPP_SAPA_OCB_SV_BIAS structure
void gpp_add_bias_data2structure(pGPP_SAPA_OCB ocb, GPPUINT1 cons_index, GPPUINT1 sat_index, GPPUINT4 pb_signal_bits, GPPUINT4 cb_signal_bits)
{
	ocb->sv[cons_index][sat_index]->bias->pb_sig_bits = pb_signal_bits;
	ocb->sv[cons_index][sat_index]->bias->cb_sig_bits = cb_signal_bits;
}

//stores data to GPP_OCB_SATCODE_BIAS structure
void gpp_add_code_bias_data2structure(pGPP_SAPA_OCB ocb, GPPUINT1 cons_index, GPPUINT1 sat_index, GPPUINT1 cb_index, GPPDOUBLE cb_correction)
{
	ocb->sv[cons_index][sat_index]->bias->code_bias[cb_index]->code_bias_correction = cb_correction;
}

//stores data to GPP_OCB_SATPHASE_BIAS structure
void gpp_add_phase_bias_data2structure(pGPP_SAPA_OCB ocb, GPPUINT1 cons_index, GPPUINT1 sat_index, GPPUINT1 pb_idex, GPPUINT1 fixflag, GPPDOUBLE cont_indicator, GPPDOUBLE pb_corr)
{
	ocb->sv[cons_index][sat_index]->bias->phase_bias[pb_idex]->fix_flag = fixflag;
	ocb->sv[cons_index][sat_index]->bias->phase_bias[pb_idex]->countinity_indicator = cont_indicator;
	ocb->sv[cons_index][sat_index]->bias->phase_bias[pb_idex]->phase_bias_correction = pb_corr;
}

//stores data to GPP_SAPA_OCB_SV structure
void gpp_add_sv_data2sructure(pGPP_SAPA_OCB ocb, GPPUINT1 cons_index, GPPUINT1 sat_index, GPPUINT1 do_not_use_flag, GPPUINT1 o_flg, GPPUINT1 c_flg, GPPUINT1 b_flg, GPPDOUBLE sv_cont_indcator)
{
	ocb->sv[cons_index][sat_index]->do_not_use = do_not_use_flag;
	ocb->sv[cons_index][sat_index]->ocb_present_flag = gpp_sapa_get_ocb_present_flags(o_flg, c_flg, b_flg);
	ocb->sv[cons_index][sat_index]->continuity_indicator = sv_cont_indcator;
}

//stores prn bits in the structure
void gpp_add_prn_bits2structure(pGPP_SAPA_OCB ocb, GPPUINT1 cons_index, GPPUINT8 prn_bits)
{
	ocb->sv_prn_bits[cons_index] = prn_bits;
}
void gpp_add_header2buffer(GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos, GPPUINT1 cons, GPPUINT1 message_sub_type, GPPUINT1 time_tag_type, GPPDOUBLE time_tag, GPPUINT4 system_id, GPPUINT4 system_processor_id, GPPUINT4 sol_issue_of_update, GPPUINT1 end_of_obc_set, GPPUINT1 yaw_flag, GPPUINT1 sat_ref_datum, GPPUINT1 ephemeris_type)
{
	printf("value%d\n", message_sub_type);
	gn_add_ulong_to_buffer(&buffer, &byte_pos, &bit_pos, 4, message_sub_type); //SF001 p_ocb->header_block[i]->message_sub_type
	printf("buffer%d\n", *buffer);
	printf("byte pos%d\n", byte_pos);
	printf("bit pos%d\n", bit_pos);
	printf("value%d\n", time_tag_type);
	gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 1,time_tag_type);      //SF002
	printf("buffer%d\n", *buffer);
	printf("byte pos%d\n", byte_pos);
	printf("bit pos%d\n", bit_pos);
	printf("value%d\n", time_tag);
	if (time_tag_type == 1)
	{
		gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 1, 1);
		gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 32,time_tag);			//SF004
		printf("buffer%d\n", *buffer);
		printf("byte pos%d\n", byte_pos);
		printf("bit pos%d\n", bit_pos);
		printf("value%d\n", system_id);
	}
	else
	{
		gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 1, 0);
		gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 12,time_tag);		//SF003
		printf("buffer%d\n", *buffer);
		printf("byte pos%d\n", byte_pos);
		printf("bit pos%d\n", bit_pos);
		printf("value%d\n", system_id);
	}
	gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 7,system_id);          //SF006
	printf("buffer%d\n", *buffer);
	printf("byte pos%d\n", byte_pos);
	printf("bit pos%d\n", bit_pos);
	printf("value%d\n", system_processor_id);
	gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 4, system_processor_id);	//SF007
	printf("buffer%d\n", *buffer);
	printf("byte pos%d\n", byte_pos);
	printf("bit pos%d\n", bit_pos);
	printf("value%d\n", sol_issue_of_update);
	gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 9, sol_issue_of_update);	//SF005
	printf("buffer%d\n", *buffer);
	printf("byte pos%d\n", byte_pos);
	printf("bit pos%d\n", bit_pos);
	printf("value%d\n", end_of_obc_set);
	gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 1, end_of_obc_set);		    //SF010
	printf("buffer%d\n", *buffer);
	printf("byte pos%d\n", byte_pos);
	printf("bit pos%d\n", bit_pos);
	printf("value%d\n", yaw_flag);
	gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 1, yaw_flag);				//SF008	
	printf("buffer%d\n", *buffer);
	printf("byte pos%d\n", byte_pos);
	printf("bit pos%d\n", bit_pos);
	printf("value%d\n", sat_ref_datum);
	gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 1, sat_ref_datum);			//SF009
	printf("buffer%d\n", *buffer);
	printf("byte pos%d\n", byte_pos);
	printf("bit pos%d\n", bit_pos);
	printf("value%d\n", ephemeris_type);
	gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 2, ephemeris_type);			//SF017
	printf("buffer%d\n", *buffer);
	printf("byte pos%d\n", byte_pos);
	printf("bit pos%d\n", bit_pos);
}
void gpp_add_sv2buffer(GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos, GPPUINT1 cons, GPPUINT1 sat, GPPUINT8 sv_prn_bits, GPPUINT1 do_not_use, GPPUINT1 ocb_present_flag, GPPDOUBLE iode_continuity, GPPUINT1 o_flag, GPPUINT1 c_flag, GPPUINT1 b_flag, long n1, long n2, long n3, long n4)
{
	if (gpp_sapa_get_max_sat_id(sv_prn_bits) >= 0 && gpp_sapa_get_max_sat_id(sv_prn_bits) < n1)
	{
		gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 2, 0);//SF011
		gn_add_longlong_to_buffer(buffer, &byte_pos, &bit_pos, n1, sv_prn_bits);//SF011
	}
	else if (gpp_sapa_get_max_sat_id(sv_prn_bits) >= n1 && gpp_sapa_get_max_sat_id(sv_prn_bits) < n2)
	{
		gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 2, 1);							//SF011
		gn_add_longlong_to_buffer(buffer, &byte_pos, &bit_pos, n2, sv_prn_bits);  //SF011
	}
	else if (gpp_sapa_get_max_sat_id(sv_prn_bits) >= n2 && gpp_sapa_get_max_sat_id(sv_prn_bits) < n3)
	{
		gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 2, 2);							//SF011
		gn_add_longlong_to_buffer(buffer, &byte_pos, &bit_pos, n3,sv_prn_bits);  //SF011
	}
	else if (gpp_sapa_get_max_sat_id(sv_prn_bits) >= n3 && gpp_sapa_get_max_sat_id(sv_prn_bits) < n4)
	{
		gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 2, 3);							//SF011
		gn_add_longlong_to_buffer(buffer, &byte_pos, &bit_pos, n4, sv_prn_bits);  //SF011
	}
	gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 1, do_not_use);	//SF013
	if (do_not_use == 1)
	{
		gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 3, ocb_present_flag);//SF014
		gpp_sapa_get_ocb_flag_value(ocb_present_flag, o_flag, c_flag, b_flag);
		if (iode_continuity == 0)//contunity indicator
		{
			gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 0);		                    //SF015
		}
		else if (iode_continuity > 0 && iode_continuity <= 1)
		{
			gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 1);		 //SF015
		}
		else if (iode_continuity > 1 && iode_continuity <= 5)
		{
			gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 2);		 //SF015
		}
		else if (iode_continuity > 5 && iode_continuity <= 10)
		{
			gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 3);		 //SF015
		}
		else if (iode_continuity > 10 && iode_continuity <= 30)
		{
			gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 4);		 //SF015
		}
		else if (iode_continuity > 30 && iode_continuity <= 60)
		{
			gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 5);		 //SF015
		}
		else if (iode_continuity > 60 && iode_continuity <= 120)
		{
			gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 6);		 //SF015
		}
		else if (iode_continuity > 120 && iode_continuity <= 360)
		{
			gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 7);		 //SF015
		}
	}
}
void gpp_add_orbit2buffer(GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos, GPPUINT1 cons, GPPUINT1 sat, GPPUINT4 iode, GPPDOUBLE orbit_radial_correction, GPPDOUBLE orbit_along_track_correction,
	GPPUINT1 yaw_flag, GPPDOUBLE orbit_cross_track_correction, GPPDOUBLE satellite_yaw,long iode_n)
{
	gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, iode_n,iode);//SF018	
	gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 14, orbit_radial_correction);//SF020
	gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 14, orbit_along_track_correction);//SF020
	gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 14, orbit_cross_track_correction);//SF020
	if (yaw_flag == 1)
	{
		gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 6, satellite_yaw);	//SF021
	}
}
void gpp_add_clock2buffer(GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos, GPPUINT1 cons, GPPUINT1 sat, GPPDOUBLE iode_continuity, GPPDOUBLE clock_correction, GPPDOUBLE user_range_error)
{
	if (iode_continuity == 0)
	{
		gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 0);	//SF022
	}
	else if (iode_continuity > 0 && iode_continuity <= 1)
	{
		gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 1);
	}
	else if (iode_continuity > 1 && iode_continuity <= 5)
	{
		gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 2);
	}
	else if (iode_continuity > 5 && iode_continuity <= 10)
	{
		gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 3);
	}
	else if (iode_continuity > 10 && iode_continuity <= 30)
	{
		gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 4);
	}
	else if (iode_continuity > 30 && iode_continuity <= 60)
	{
		gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 5);
	}
	else if (iode_continuity > 60 && iode_continuity <= 120)
	{
		gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 6);
	}
	else if (iode_continuity > 120 && iode_continuity <= 320)
	{
		gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 7);
	}
	gn_add_double_to_buffer(buffer, byte_pos, bit_pos, 14, clock_correction);				//SF020
	if (user_range_error == 0)
	{
		gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 0);	//SF024
	}
	else if (user_range_error > 0 && user_range_error <= 0.01)
	{
		gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 1);	//SF024
	}
	else if (user_range_error > 0.01 && user_range_error <= 0.02)
	{
		gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 2);		//SF024	
	}
	else if (user_range_error > 0.02 && user_range_error <= 0.05)
	{
		gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 3);												//SF024	
	}
	else if (user_range_error > 0.05 && user_range_error <= 0.1)
	{
		gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 4);												//SF024	
	}
	else if (user_range_error > 0.1 && user_range_error <= 0.3)
	{
		gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 5);												//SF024	
	}
	else if (user_range_error > 0.3 && user_range_error <= 1.0)
	{
		gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 6);												//SF024	
	}
	else if (user_range_error > 1.0)
	{
		gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 7);												//SF024	
	}
}
GPPUINT4 gpp_add_phase_bias_mask2buffer(GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos, GPPUINT1 cons, GPPUINT1 sat, GPPUINT4 pb_sig_bits, long n1,long n2)
{
	GPPUINT4 max_sig = 0;
	if (gpp_sapa_get_max_bias_id(pb_sig_bits) == n1)
	{
		max_sig++;
		gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 1, 0);
		gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, n1, pb_sig_bits);		        //SF026
	}
	else if (gpp_sapa_get_max_bias_id(pb_sig_bits) == n2)
	{
		max_sig++;
		gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 1, 1);
		gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, n2, pb_sig_bits);    			//SF026
	}
	return max_sig;
}
GPPUINT4 gpp_add_code_bias_mask2buffer(GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos, GPPUINT1 cons, GPPUINT1 sat, GPPUINT4 cb_sig_bits,long n1,long n2)
{
	GPPUINT4 max_sng=0;
	if (gpp_sapa_get_max_bias_id(cb_sig_bits) <= n1)
	{
		max_sng++;
		gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 1, 0);
		gn_add_long_to_buffer(buffer, &byte_pos, &bit_pos, n1, cb_sig_bits);				//SF028	
	}
	else if (gpp_sapa_get_max_bias_id(cb_sig_bits) == n2)
	{
		max_sng++;
		gn_add_long_to_buffer(buffer, &byte_pos, &bit_pos, 1, cb_sig_bits);
		gn_add_long_to_buffer(buffer, &byte_pos, &bit_pos, n2, cb_sig_bits);
	}
	return max_sng;
}
void gpp_add_phasebias2buffer(GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos, GPPUINT1 cons, GPPUINT1 sat, GPPUINT1 fix_flag, GPPDOUBLE iode_continuity, GPPDOUBLE phase_bias_correction)
{
		gn_add_ulong_to_buffer(buffer, &byte_pos, &bit_pos, 1,fix_flag);	//SF023
		if (iode_continuity == 0)//contunity indicator in phase structure
		{
			gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 0);		                    //SF015
		}
		else if (iode_continuity > 0 && iode_continuity <= 1)
		{
			gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 1);		 //SF015
		}
		else if (iode_continuity > 1 && iode_continuity <= 5)
		{
			gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 2);		 //SF015
		}
		else if (iode_continuity > 5 && iode_continuity <= 10)
		{
			gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 3);		 //SF015
		}
		else if (iode_continuity > 10 &&iode_continuity <= 30)
		{
			gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 4);		 //SF015
		}
		else if (iode_continuity > 30 && iode_continuity <= 60)
		{
			gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 5);		 //SF015
		}
		else if (iode_continuity > 60 && iode_continuity <= 120)
		{
			gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 6);		 //SF015
		}
		else if (iode_continuity > 120 && iode_continuity <= 360)
		{
			gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 3, 7);		 //SF015
		}
		gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 14, phase_bias_correction);//SF020
}
void gpp_add_codebiasbuffer(GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos, GPPUINT1 cons, GPPUINT1 sat, GPPDOUBLE code_bias_correction)
{
	
		gn_add_double_to_buffer(buffer, &byte_pos, &bit_pos, 11, code_bias_correction);			//SF029
}