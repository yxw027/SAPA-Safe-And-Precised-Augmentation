#include <stdio.h>
#include <string.h>
#include "gpp_sapa.h"

void gpp_sapa_ocb_asciifile2buffer()
{
	FILE *pAsciiDataset = NULL; // file pointer to ASCII file containing datasets
	char *line_buffer = NULL;   // Read ASCII file line by line and store in this buffer
	char *line_buffer_for_common = NULL;   // Read ASCII file line by line and store in this buffer
	char *tokens[30] = { '\0' };        // Store the tokens of the line read from the ASCII file
	unsigned int size = 256;    // size of line_buffer and tokens 
	fpos_t  last_pos;			// last position of pointer in file
	int data_count = 0;			//Number of Satellites for End OF OCB Data
	int last_data_count = 0;			//Number of Satellites for End OF OCB Data
	int index_cons = 0;			//Number of Satellites for End OF OCB Data
	int index_sat = 0;			//Number of Satellites for End OF OCB Data
	//char *getLine = NULL;   // Read ASCII file line by line and store in this buffer
	int matchFound = 0;

	//Ascii Data set file
	char *ascii_filename = "ascii/SapaInteropTestDataset_001.ocb";
	//char *ascii_filename = "ascii/SapaInteropTestDataset_002.ocb";
	//char *ascii_filename = "ascii/SapaInteropTestDataset_003.ocb";
	//char *ascii_filename = "ascii/SapaInteropTestDataset_004.ocb";

	pGPP_SAPA_OCB pOCB = NULL;//Structure for SAPA
	GPPUCHAR *ocb_binary_buffer = NULL;//Buffer to store the binary data
	GPPLONG *byte_pos = 0;//Starting byte
	GPPLONG *bit_pos = 0;//Starting bit
	ocb_binary_buffer = (unsigned char *)calloc(1, sizeof(unsigned char));

	pAsciiDataset = fopen(ascii_filename, "r");
	if (pAsciiDataset)
	{
		//Allocate memory for line_buffer
		line_buffer = (GPPUCHAR*)calloc(size, sizeof(GPPUCHAR)); //Assuming Max  character of line is 255
		line_buffer_for_common = (GPPUCHAR*)calloc(size, sizeof(GPPUCHAR)); //Assuming Max  character of line is 255

		while (fgets(line_buffer, size, pAsciiDataset) != NULL)
		{
			/* skip lines beginning with '#' or blank lines  */
			if (*line_buffer == '#' || !*line_buffer)
			{
				continue;
			}
			else
			{
				//Check for OCB_COMMON_INFO in parsed token
				strcpy(line_buffer_for_common, line_buffer);
				GPPUINT4 ntok = gpp_sapa_split_arg_to_tokens(line_buffer, tokens);
				printf("TOKEN = %s \n", tokens[0]);
				if ((strncmp(tokens[0], "<OCB_COMMON_INFO>", 17) == 0) && ntok == 9)
				{
					if (!pOCB)
					{
						pOCB = calloc(1, sizeof(GPP_SAPA_OCB));
						pOCB->header_block = malloc(GPP_SAPA_MAX_CONS * sizeof(GPP_SAPA_HEADER_BLOCK));
						pOCB->sv = calloc(1, sizeof(GPP_SAPA_OCB_SV));
						pOCB->sv = malloc(GPP_SAPA_MAX_CONS * sizeof(GPP_SAPA_OCB_SV));
						int c;
						int d;
						int e;
						for (c = 0; c < GPP_SAPA_MAX_CONS; c++)
							pOCB->sv[c] = calloc(1, sizeof(GPP_SAPA_OCB_SV));
							pOCB->sv[c] = malloc(GPP_SAPA_MAX_SAT * sizeof(GPP_SAPA_OCB_SV));

						for (c = 0; c < GPP_SAPA_MAX_CONS; c++)
						{
							for (d = 0; d < GPP_SAPA_MAX_SAT; d++)
							{
								pOCB->sv[c][d] = calloc(1, sizeof(GPP_SAPA_OCB_SV));
								pOCB->sv[c][d] = malloc(sizeof(GPP_SAPA_OCB_SV));
								pOCB->sv[c][d]->orb = malloc(sizeof(GPP_SAPA_OCB_SV_ORBIT));
								pOCB->sv[c][d]->clk = malloc(sizeof(GPP_SAPA_OCB_SV_CLOCK));
								pOCB->sv[c][d]->bias = malloc(sizeof(GPP_SAPA_OCB_SV_BIAS));
								pOCB->sv[c][d]->bias->phase_bias = malloc(GPP_SAPA_MAX_SIG * sizeof(GPP_OCB_SATPHASE_BIAS));
								pOCB->sv[c][d]->bias->code_bias = malloc(GPP_SAPA_MAX_SIG * sizeof(GPP_OCB_SATCODE_BIAS));
								for (e = 0; e < GPP_SAPA_MAX_SIG; e++)
								{
									pOCB->sv[c][d]->bias->phase_bias[e] = malloc(sizeof(GPP_OCB_SATPHASE_BIAS));
									pOCB->sv[c][d]->bias->code_bias[e] = malloc(sizeof(GPP_OCB_SATPHASE_BIAS));
								}
							}
						}
					}
					//last_pos = ftell(pAsciiDataset);
					fgetpos(pAsciiDataset, &last_pos);
					while (fgets(line_buffer, size, pAsciiDataset) != NULL)
					{
						/* skip lines beginning with '#' or blank lines  */
						if (*line_buffer == '#' || !*line_buffer || *line_buffer == NULL)
						{
							continue;
						}
						else
						{
							memset(tokens, NULL, sizeof(tokens));
							printf("In While Line: %s with size: %d\n", line_buffer,strlen(line_buffer));
							gpp_sapa_split_arg_to_tokens(line_buffer, tokens);
							printf("In While TOKEN[0] = %s \n", tokens[0]);

							if ((strncmp(tokens[0], "<OCB_SATELLITE_DATA>", 20) == 0))						//Checking for Satellite Data
							{
								data_count++;
								printf("line: %d", ftell(pAsciiDataset));
							}
							if ((strncmp(tokens[0], "<OCB_COMMON_INFO>", 17) == 0))						//Checking for Satellite Data
							{
								break;
							}
						}
					}
					//fseek(pAsciiDataset, last_pos, SEEK_SET);
					fsetpos(pAsciiDataset, &last_pos);
					//dataCount++;
					//if (!pOCB->header_block)													//0 set only for testing
					//	malloc(16*sizeof(GPP_SAPA_HEADER_BLOCK));
					//checkSatFlag = true;

					// Check if no of tokens is 8
					// If no of tokens is not equal to 8, skip to next COMMON_INFO

					//MESSAGE SUBTYPE (FETCH FROM NEXT LINE)
					//pOCB->header_block[0]->message_sub_type

					last_data_count++;


					printf("%s \n", line_buffer_for_common);
					memset(tokens, NULL, sizeof(tokens));
					gpp_sapa_split_arg_to_tokens(line_buffer_for_common, tokens);
					printf("TOKEN = %s \n", tokens[0]);

					pOCB->header_block[0]->time_tag_type = 1;									//0 OR 1 User's Preference

					GPPT_WNT wn_t = { 0, }; // Geo++ Time Handling Structure
					wn_t.wn = atoi(tokens[1]);
					wn_t.t = atof(tokens[2]);

					GPPDOUBLE sec;
					if (pOCB->header_block[0]->time_tag_type) {
						sec = GPP_T_DIFF(SAPA_GPS_WEEK_20100101, SAPA_GPS_SEC_20100101, wn_t.wn, wn_t.t);
						printf("%d\n", sec);
					}
					else 
					{
						sec = ((GPPUINT4)wn_t.t) % 3600;
					}

					pOCB->header_block[0]->time_tag = sec;
					//printf("%d", pOCB->header_block[0]->time_tag);

					pOCB->header_block[0]->system_id = atoi(tokens[3]);
					//printf("%s", pOCB->header_block[0]->system_id);
						
						
					pOCB->header_block[0]->system_processor_id = atoi(tokens[4]);
					//printf("%s", pOCB->header_block[0]->system_processor_id);
						
					pOCB->header_block[0]->sol_issue_of_update = atoi(tokens[5]);
					//printf("%s", pOCB->header_block[0]->sol_issue_of_update);
						
					//END_OF_OBC_SET to be added

					pOCB->header_block[0]->sat_ref_datum = atoi(tokens[6]);
					//printf("%s", pOCB->header_block[0]->sat_ref_datum);
						
					pOCB->header_block[0]->yaw_flag = atoi(tokens[7]);
					//printf("%s", pOCB->header_block[0]->yaw_flag);
						
					pOCB->header_block[0]->ephemeris_type = atoi(tokens[8]);
					//printf("%s", pOCB->header_block[0]->ephemeris_type);

					while (fgets(line_buffer, size, pAsciiDataset) != NULL)
					{//Extracting next line from file
						if (*line_buffer == '#' || !*line_buffer || *line_buffer == NULL)
						{
							continue;
						}
						else
						{
							printf("%s \n", line_buffer);
							memset(tokens, NULL, sizeof(tokens));
							gpp_sapa_split_arg_to_tokens(line_buffer, tokens);
							printf("TOKEN = %s \n", tokens[0]);

							if ((strncmp(tokens[0], "<OCB_COMMON_INFO>", 17) == 0))
							{
								//fseek(pAsciiDataset, last_pos, SEEK_SET);
								fsetpos(pAsciiDataset, &last_pos);
								index_cons++;
								break;
							}

							if ((strncmp(tokens[0], "<OCB_SATELLITE_DATA>", 20) == 0))						//Checking for Satellite Data
							{
								//Getting Index of token for constellation number
								int cons = 0;
								int sat = 0;

								if (tokens[1][0] == 'G')
									cons = 0;
								else if (tokens[1][0] == 'R')
									cons = 1;

								char sat_id[] = { tokens[1][1] , tokens[1][2] , tokens[1][3] };												//Checking satellite number
								sat = atoi(sat_id);

								//char s			
								// The no of tokens must be XX
								// If no of tokens is not 14 then skip to next SATELLITE_DATA

								// If DO NOT USE FLAG ==1, then skip to next SATELLITE DATA in the same COMMON_INFO 
								// If this is last satellite data in that commmon_info then it should go to NEXT COMMON_INFO

								// check for any invliad fileds, out of range fields, 
								// If any invlid field is found, skip to next SATELLITE_DATA in the same COMMON_INFO field
								// If this is last satellite data in that commmon_info then it should go to NEXT COMMON_INFO

								pOCB->sv_prn_bits[cons] = gpp_sapa_set_satellite_mask_position(pOCB->sv_prn_bits[cons], sat);

								pOCB->sv[cons][sat]->do_not_use = atoi(tokens[2]);

								pOCB->sv[cons][sat]->ocb_present_flag = gpp_sapa_set_ocb_present_flags(pOCB->sv[cons][sat]->ocb_present_flag, 0, atoi(tokens[3]));

								pOCB->sv[cons][sat]->ocb_present_flag = gpp_sapa_set_ocb_present_flags(pOCB->sv[cons][sat]->ocb_present_flag, 1, atoi(tokens[4]));

								pOCB->sv[cons][sat]->ocb_present_flag = gpp_sapa_set_ocb_present_flags(pOCB->sv[cons][sat]->ocb_present_flag, 2, atoi(tokens[5]));

								pOCB->sv[cons][sat]->continuity_indicator = atof(tokens[6]);

								pOCB->sv[cons][sat]->orb->iode = atoi(tokens[7]);

								pOCB->sv[cons][sat]->clk->iode_continuity = atof(tokens[8]);

								pOCB->sv[cons][sat]->orb->orbit_radial_correction = atof(tokens[9]);

								pOCB->sv[cons][sat]->orb->orbit_along_track_correction = atof(tokens[10]);

								pOCB->sv[cons][sat]->orb->orbit_cross_track_correction = atof(tokens[11]);

								//tokens[12]

								pOCB->sv[cons][sat]->orb->satellite_yaw = atof(tokens[13]);

								pOCB->sv[cons][sat]->clk->clock_correction = atof(tokens[14]);

								pOCB->sv[cons][sat]->clk->user_range_error = atof(tokens[15]);

								fgets(line_buffer, size, pAsciiDataset);										//Reading next line from file
								//*tokens = NULL;
								memset(tokens, NULL, sizeof(tokens));
								printf("%s \n", line_buffer);
								printf("TOKEN = %s\n", tokens[0]);
								gpp_sapa_split_arg_to_tokens(line_buffer, tokens);

								if ((strncmp(tokens[0], "<OCB_SATPHASE_BIAS>", 19) == 0))						//Checking for Phase Bias data
								{
									int count_index = 1;
									int index = atoi(tokens[count_index]);										//Phase Bias data slot

									while (tokens[count_index] != NULL)											//Loop to access all the data slots and write to structures
									{
										pOCB->sv[cons][sat]->bias->pb_sig_bits = gpp_sapa_set_bias_mask_position(pOCB->sv[cons][sat]->bias->pb_sig_bits, index);

										count_index++;
										pOCB->sv[cons][sat]->bias->phase_bias[index]->phase_bias_correction = atof(tokens[count_index]);

										count_index++;
										pOCB->sv[cons][sat]->bias->phase_bias[index]->fix_flag = atoi(tokens[count_index]);

										count_index++;
										pOCB->sv[cons][sat]->bias->phase_bias[index]->countinity_indicator = atof(tokens[count_index]);

										count_index++;

										if (tokens[count_index] == NULL)
										{
											break;
										}
										
										index = atoi(tokens[count_index]);
									}

									fgets(line_buffer, size, pAsciiDataset);									//Reading next line from file
									printf("%s \n", line_buffer);
									memset(tokens, NULL, sizeof(tokens));
									printf("TOKEN = %s\n", tokens[0]);
									gpp_sapa_split_arg_to_tokens(line_buffer, tokens);

									if ((strncmp(tokens[0], "<OCB_SATCODE_BIAS>", 18) == 0))					//Checking for Code Bias data
									{
										int count_index_code = 1;
										int index_code = atoi(tokens[count_index_code]);						//Code Bias data slot

										while (tokens[count_index_code] != NULL)								//Loop to access all the data slots and write to structures
										{
											pOCB->sv[cons][sat]->bias->cb_sig_bits = gpp_sapa_set_bias_mask_position(pOCB->sv[cons][sat]->bias->cb_sig_bits, index_code);

											count_index_code++;
											pOCB->sv[cons][sat]->bias->code_bias[index_code]->code_bias_correction = atoi(tokens[count_index_code]);

											count_index_code++;

											if (tokens[count_index_code] == NULL)
											{
												break;
											}

											index_code = atoi(tokens[count_index_code]);
										}
									}// CODE_BIAS ends
								}// PHASE_BIAS ends

							} // SATALLITE_DATA ends
							
						}
						//last_pos = ftell(pAsciiDataset);
						fgetpos(pAsciiDataset, &last_pos);
					}
					/*else
					{
						goto NEXT_COMMON;
					}*/

				}// COMMON_INFO ends

			}// else ends

			//gpp_sapa_test_poplate_ocb_struct_dymmy();
			//byte_pos += ;
			//bit_pos += ;
		}//while ends
		gpp_sapa_ocb2buffer(pOCB, ocb_binary_buffer, byte_pos, bit_pos);
		while (1)
		{

		}
	}//fopen ends
	else
	{
		printf("%s", "The file could not be opened");
	}//else ends
}


GPPUINT1 gpp_sapa_set_ocb_present_flags(GPPUINT1 ref_obj, int index, int setvalue)
{
	if(setvalue == 1)
		ref_obj = ((1 << index) | ref_obj);

	return ref_obj;
}

GPPUINT4 gpp_sapa_split_arg_to_tokens(char **_buffer, GPPUCHAR **tok)
{
	printf("Value from file: %swith size: %d\n", _buffer, strlen(_buffer));
	GPPUINT1 tok_pos = 0;
	GPPUCHAR *temp = NULL;

	temp = strtok(_buffer, " ,");
	while (temp != NULL)
	{
		printf("Token Position: %d Value: %s\n", tok_pos, temp);
		tok[tok_pos++] = temp;
		temp = strtok(NULL, " ,");
	}

	printf("TOKEN 13: %s \n",tok[13]);
	return tok_pos;
}


