#ifndef GPP_SAPA_H
#define GPP_SAPA_H
/************************************************* * GPS Week and Second of 2010/01/01 00:00:00 UTC
*****************************************/
#define SAPA_GPS_WEEK_20100101 1564
#define SAPA_GPS_SEC_20100101 432000
#include "gpptime.h"
#include "compiler.h" //GPP types
#include <stdlib.h>

/*******************************************
 * SAPA specific parameters
 *******************************************/
#define GPP_SAPA_MAX_CONS   16  /* Constellation*/
#define GPP_SAPA_MAX_SAT    64  /* SF011, SF012 (special values) */
#define GPP_SAPA_MAX_SIG    32  /* SF027, SF028 (okay although only 10 bits needed) */

typedef struct GPP_SAPA_HEADER_BLOCK {
	GPPUINT1		message_sub_type;					 //SF001	    -- first charcter of satellite ID
	GPPUINT1		time_tag_type;						 //SF002	    -- can be 0 or 1,will be set manually in the code
	GPPDOUBLE		time_tag;							 //SF003orSF004 -- <ascii_in>.ocb's OCB_COMMON_INFO[2]
	GPPUINT4		system_id;							 //SF006		-- <ascii_in>.ocb's OCB_COMMON_INFO[3]
	GPPUINT4		system_processor_id;				 //SF007        -- <ascii_in>.ocb's OCB_COMMON_INFO[4]
	GPPUINT4		sol_issue_of_update;				 //SF005        -- <ascii_in>.ocb's OCB_COMMON_INFO[5]
	GPPUINT1		end_of_obc_set;						 //SF010        -- will be set in the code
	GPPUINT1		yaw_flag;							 //SF008        -- <ascii_in>.ocb's OCB_COMMON_INFO[7]
	GPPUINT1		sat_ref_datum;						 //SF009        -- <ascii_in>.ocb's OCB_COMMON_INFO[6]
	GPPUINT1		ephemeris_type;						 //SF016orSF017 -- <ascii_in>.ocb's OCB_COMMON_INFO[8]
} GPP_SAPA_HEADER_BLOCK , *pGPP_SAPA_HEADER_BLOCK;

typedef struct GPP_SAPA_OCB_SV_ORBIT{
	GPPUINT4  iode;										 //SF018orSF019 -- <ascii_in>.ocb's OCB_SATELLITE_DATA[7]
	GPPDOUBLE orbit_radial_correction;					 //SF020		-- <ascii_in>.ocb's OCB_SATELLITE_DATA[9]
	GPPDOUBLE orbit_along_track_correction;				 //SF020		-- <ascii_in>.ocb's OCB_SATELLITE_DATA[10]
	GPPDOUBLE orbit_cross_track_correction;				 //SF020        -- <ascii_in>.ocb's OCB_SATELLITE_DATA[11]
	GPPDOUBLE satellite_yaw;							 //SF021        -- <ascii_in>.ocb's OCB_SATELLITE_DATA[13]
} GPP_SAPA_OCB_SV_ORBIT, *pGPP_SAPA_OCB_SV_ORBIT;

typedef struct GPP_SAPA_OCB_SV_CLOCK{
	GPPDOUBLE iode_continuity;							 //SF022        -- <ascii_in>.ocb's OCB_SATELLITE_DATA[8]
	GPPDOUBLE clock_correction;							 //SF020        -- <ascii_in>.ocb's OCB_SATELLITE_DATA[14]
	GPPDOUBLE user_range_error;							 //SF024        -- <ascii_in>.ocb's OCB_SATELLITE_DATA[15]
} GPP_SAPA_OCB_SV_CLOCK, *pGPP_SAPA_OCB_SV_CLOCK;

typedef struct GPP_OCB_SATPHASE_BIAS
{
	GPPUINT1   fix_flag;								 //SF023        -- <ascii_in>.ocb's OCB_SATPHASE_BIAS[3]
	GPPDOUBLE  countinity_indicator;					 //SF015        -- <ascii_in>.ocb's OCB_SATPHASE_BIAS[4]
	GPPDOUBLE  phase_bias_correction;					 //SF020        -- <ascii_in>.ocb's OCB_SATPHASE_BIAS[2]
} GPP_OCB_SATPHASE_BIAS, *pGPP_OCB_SATPHASE_BIAS;

typedef struct GPP_OCB_SATCODE_BIAS
{
	GPPDOUBLE  code_bias_correction;					 //SF029       -- <ascii_in>.ocb's OCB_SATCODE_BIAS[2]
} GPP_OCB_SATCODE_BIAS, *pGPP_OCB_SATCODE_BIAS;

typedef struct GPP_SAPA_OCB_SV_BIAS {
	GPPUINT4			   pb_sig_bits;									//to control the phase bias signals (SF025, SF026)
	pGPP_OCB_SATPHASE_BIAS *phase_bias;				//PhaseBias
	GPPUINT4			   cb_sig_bits;									//control Code Bias (SF027)
	pGPP_OCB_SATCODE_BIAS *code_bias;					//CodeBias	 
} GPP_SAPA_OCB_SV_BIAS, *pGPP_SAPA_OCB_SV_BIAS;


typedef struct GPP_SAPA_OCB_SV{
    pGPP_SAPA_OCB_SV_ORBIT  orb;
    pGPP_SAPA_OCB_SV_CLOCK  clk;
    pGPP_SAPA_OCB_SV_BIAS   bias;
	GPPUINT1  do_not_use;								//SF013       -- <ascii_in>.ocb's OCB_SATELLITE_DATA[2]
	GPPUINT1  ocb_present_flag;						    //SF014       -- <ascii_in>.ocb's OCB_SATELLITE_DATA[3]
	GPPDOUBLE continuity_indicator;					    //SF015       -- <ascii_in>.ocb's OCB_SATELLITE_DATA[6]
} GPP_SAPA_OCB_SV, *pGPP_SAPA_OCB_SV;

typedef struct GPP_SAPA_OCB{
	GPPUINT8    sv_prn_bits[GPP_SAPA_MAX_CONS];
	pGPP_SAPA_HEADER_BLOCK *header_block;	//Header Block
    pGPP_SAPA_OCB_SV **sv;							        //get access via sv[cons][sat]; cons=GPS,GLO; sat=0,1,2,...N
} GPP_SAPA_OCB, *pGPP_SAPA_OCB;

typedef struct GPP_SAPA_HPAC{
    int dummy;
} GPP_SAPA_HPAC, *pGPP_SAPA_HPAC;

typedef struct GPP_SAPA_AREA{
    int dummy;
}GPP_SAPA_AREA, *pGPP_SAPA_AREA;

typedef struct GPP_SAPA_USE_STATES{
    pGPP_SAPA_OCB   ocb;
    pGPP_SAPA_HPAC  hpac;
    pGPP_SAPA_AREA  area;
} GPP_SAPA_USE_STATES, *pGPP_SAPA_USE_STATES;

/******************************************************************************
 *  \brief Write SAPA OCB content to buffer
 *
 *  \param[in]  ocb     Pointer to GPP_SAPA_OCB structure
 *  \param[in]  *buffer Pointer to buffer
 *  \param[in]  *byte_pos
 *  \param[in]  *bit_pos
 *
 *  \retval  needed bits (>0) or error code (<0)

 *****************************************************************************/
GPPLONG gpp_sapa_ocb2buffer(const pGPP_SAPA_OCB ocb, GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos);
GPPLONG gpp_sapa_buffer2ocb(pGPP_SAPA_OCB ocb, const GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos);

GPPLONG gpp_sapa_hpac2buffer(const pGPP_SAPA_HPAC hpac, GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos);
GPPLONG gpp_sapa_buffer2hpac(pGPP_SAPA_HPAC hpac, const GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos);

GPPLONG gpp_sapa_area2buffer(const pGPP_SAPA_AREA area, GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos);
GPPLONG gpp_sapa_buffer2area(pGPP_SAPA_AREA area, const GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos);

//Internal functions

//Returns 1 if a bit at position pos in prnbits is set else return 0
GPPUINT1 gpp_sapa_get_satellite_present_bit(GPPUINT8 prn_bits, GPPUINT1 pos);

//Return Seconds passed in the hour when data is received
GPPINT gpp_sapa_get_hourly_time_tag(GPPINT seconds_of_week);

//Returns seconds passed since the beginning including all gps_weeks
GPPINT gpp_sapa_get_full_time_tag(GPPINT gps_week, GPPINT seconds_of_week);

//converts three seprate flas into one 3 bit flag to check the presence of ocb blocks
GPPUINT1 gpp_sapa_get_ocb_present_flags(GPPINT1 o_flag, GPPUINT1 c_flag, GPPUINT1 b_flag);

//Returns Orbit ,Clock and  Bias flag value
void gpp_sapa_get_ocb_flag_value(GPPUINT1 ocb_present_flag, const GPPUINT1 *o_flag, const GPPUINT1 *c_flag, const GPPUINT1 *b_flag);

//Returns highest order of satellite set
GPPUINT1 gpp_sapa_get_max_sat_id(GPPUINT8 sat_mask);

//Returns highest order of bias mask set
GPPUINT1 gpp_sapa_get_max_bias_id(GPPUINT2 bias_mask);

//Set OCB present flag bit
GPPUINT1 gpp_sapa_set_ocb_present_flags(GPPUINT1 ref_obj, int index, int setvalue);
//Set a particular bit in satellite mask
GPPUINT8 gpp_sapa_set_satellite_mask_position(GPPUINT8 sat_mask, GPPUINT1 sat_pos);

//Set a particular bit in bias mask
GPPUINT2 gpp_sapa_set_bias_mask_position(GPPUINT2 bias_mask, GPPUINT1 bias_pos);

GPPUINT4 gpp_sapa_split_arg_to_tokens(char **_buffer, GPPUCHAR **tok);

void gpp_add_header2buffer(GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos, GPPUINT1 cons, GPPUINT1 message_sub_type, GPPUINT1 time_tag_type, GPPDOUBLE time_tag, GPPUINT4 system_id, GPPUINT4 system_processor_id, GPPUINT4 sol_issue_of_update, GPPUINT1 end_of_obc_set, GPPUINT1 yaw_flag, GPPUINT1 sat_ref_datum, GPPUINT1 ephemeris_type);
void gpp_add_sv2buffer(GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos, GPPUINT1 cons, GPPUINT1 sat, GPPUINT8 sv_prn_bits, GPPUINT1 do_not_use, GPPUINT1 ocb_present_flag, GPPDOUBLE iode_continuity, GPPUINT1 o_flag, GPPUINT1 c_flag, GPPUINT1 b_flag, long n1, long n2, long n3, long n4);
void gpp_add_orbit2buffer(GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos, GPPUINT1 cons, GPPUINT1 sat, GPPUINT4 iode, GPPDOUBLE orbit_radial_correction, GPPDOUBLE orbit_along_track_correction,
	GPPUINT1 yaw_flag, GPPDOUBLE orbit_cross_track_correction, GPPDOUBLE satellite_yaw, long iode_n);
void gpp_add_clock2buffer(GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos, GPPUINT1 cons, GPPUINT1 sat, GPPDOUBLE iode_continuity, GPPDOUBLE clock_correction, GPPDOUBLE user_range_error);
GPPUINT4 gpp_add_phase_bias_mask2buffer(GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos, GPPUINT1 cons, GPPUINT1 sat, GPPUINT4 pb_sig_bits, long n1, long n2);
GPPUINT4 gpp_add_code_bias_mask2buffer(GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos, GPPUINT1 cons, GPPUINT1 sat, GPPUINT4 cb_sig_bits, long n1, long n2);
void gpp_add_phasebias2buffer(GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos, GPPUINT1 cons, GPPUINT1 sat, GPPUINT1 fix_flag, GPPDOUBLE iode_continuity, GPPDOUBLE phase_bias_correction);
void gpp_add_codebiasbuffer(GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos, GPPUINT1 cons, GPPUINT1 sat, GPPDOUBLE code_bias_correction);

#endif // GPP_SAPA_H
