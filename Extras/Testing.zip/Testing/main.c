#include <stdio.h>
#include <stdlib.h>
#include <conio.h> //For _getch() // will be removed in the infal stage of project

#include "bit2buff.h"
#include "compiler.h" //GPP types
#include "gpp_sapa.h"


int main()
{
	//GPPUCHAR *buffer=calloc(100, sizeof(GPPUCHAR));
	//GN_LONG byte_pos=0, bit_pos=0;

	sapa_read_ocb_ascii(); // Read the OCB ASCII files and save in SAPA Structures
	_getch(); // Hold the output screen 

	//if(buffer) free(buffer);
    return 0;
}
