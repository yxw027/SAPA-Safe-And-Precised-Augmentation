#ifndef GPP_SAPA_H
#define GPP_SAPA_H

#include "compiler.h"

/*******************************************
 * SAPA specific parameters
 *******************************************/
#define GPP_SAPA_MAX_SYS    16  /* OCB, HPAC subtype*/
#define GPP_SAPA_MAX_SAT    64  /* SF011, SF012 (special values) */
#define GPP_SAPA_MAX_SIG    32  /* SF027, SF028 (okay although only 10 bits needed) */


typedef struct GPP_SAPA_OCB_SV_ORBIT {
	GPPULONG iode;     //IODE of the reference orbit
	GPPDOUBLE rac_correction[3];    //orbit correction Radial, Along Track, Across Track
	GPPDOUBLE satellite_yaw;         //Satellite Yaw value
} GPP_SAPA_OCB_SV_ORBIT, *pGPP_SAPA_OCB_SV_ORBIT;


typedef struct GPP_SAPA_OCB_SV_CLOCK {
	GPPDOUBLE time_since_last_iode; //Time Since Last Iode Change(in sec.)
	GPPDOUBLE User_range_error;      //User Change Error
} GPP_SAPA_OCB_SV_CLOCK, *pGPP_SAPA_OCB_SV_CLOCK;
/*
typedef struct GPP_SAPA_OCB_SV_BIAS {

	pGPP_OCB_SATPHASE_BIAS phase_bias;
	pGPP_OCB_SATCODE_BIAS  code_bias;
} GPP_SAPA_OCB_SV_BIAS, *pGPP_SAPA_OCB_SV_BIAS;
*/

typedef struct GPP_SAPA_OCB_SV {
	pGPP_SAPA_OCB_SV_ORBIT  orb;
	pGPP_SAPA_OCB_SV_CLOCK  clk;
	//pGPP_SAPA_OCB_SV_BIAS   bias;
} GPP_SAPA_OCB_SV, *pGPP_SAPA_OCB_SV;



typedef struct GPP_SAPA_OCB {

	pGPP_SAPA_OCB_SV **sv;     //get access via sv[sys][sat]; sys=GPS,GLO; sat=0,1,2,...N
	GPPBOOL do_not_use_flag;    // 0 = satellite may be used, 1 = satellite not to be used.
	GPPBOOL orbit_block_flag;    // 0 = orbit block shall not be encoded, 1 = orbit block shall be encoded.
	GPPBOOL clock_block_flag;    // 0 = clock block shall not be encoded, 1 = clock block shall be encoded.
	GPPBOOL bias_block_flag;    // 0 = bias block shall not be encoded, 1 = bias block shall be encoded.
	GPPDOUBLE sat_continuity_time;   // The satellite has had no discontinuity within the last X seconds.
} GPP_SAPA_OCB, *pGPP_SAPA_OCB;



typedef struct GPP_SAPA_HPAC{
    int dummy;
} GPP_SAPA_HPAC, *pGPP_SAPA_HPAC;


typedef struct GPP_SAPA_AREA{
    int dummy;
}GPP_SAPA_AREA, *pGPP_SAPA_AREA;

typedef struct GPP_SAPA_HEADERBLOCK {
	GPPDOUBLE Seconds_of_week;    // Seconds of week of the epoch in GPS time.
	GPPINT    System_ID;     // Unique identification of the current stream (SF 006)
	GPPINT   System_Processor_ID;   // Unique identification of the processor providing data for the stream (SF 007).
	GPPINT   Solution_IOU;     // Indicates when different parts of the correction message can be combined for processing (SF 005).
	GPPBOOL   Sat_reference_datum;   // Satellite reference datum (SF 009).
	GPPBOOL   Yaw_Encode_Flag;    // 0 = yaw shall not be encoded, 1 = yaw shall be encoded.
	GPPINT   Ephemeris_Flag;    // 0 = Ephemeris type L1 Nav, all others are to be considered invalid.


}GPP_SAPA_HEADERBLOCK, *pGPP_SAPA_HEADERBLOCK;

typedef struct GPP_SAPA_USE_STATES {
	pGPP_SAPA_OCB   ocb;
	pGPP_SAPA_HPAC  hpac;
	pGPP_SAPA_AREA  area;
}GPP_SAPA_USE_STATES, *pGPP_SAPA_USE_STATES;


/*
typedef struct GPP_OCB_SATELLITE_DATA {
 //char satellite_id;
 //bool do_not_use_flag;    // 0 = satellite may be used, 1 = satellite not to be used.
 //bool orbit_block_flag;    // 0 = orbit block shall not be encoded, 1 = orbit block shall be encoded.
 //bool clock_block_flag;    // 0 = clock block shall not be encoded, 1 = clock block shall be encoded.
 //bool bias_block_flag;    // 0 = bias block shall not be encoded, 1 = bias block shall be encoded.
 //double sat_continuity_time;   // The satellite has had no discontinuity within the last X seconds.
 //int iode;
 //double time_since_last_iode_change;
 //double radial_correction;
 //double along_track_correction;
 //double cross_track_correction;
 //bool satellite_yaw_valid;
 //double satellite_yaw;
 //double clock_correction;
 //double user_range_error;
}GPP_OCB_SATELLITE_DATA,*pGPP_OCB_SATELLITE_DATA;

*/

typedef struct GPP_OCB_SATPHASE_BIAS
{
	GPPUINT1  phase_bias_slot;       //Phase Bias Slot(Staring with 0)
	GPPDOUBLE phase_bias_slot_y_value;     //Phase Bias Values(in meters)
	GPPBOOL   phase_bias_slot_y_fix_flag;   //Phase Bias Fixed Flag(fix=0, not fix=1)
	GPPDOUBLE phase_bias_slot_y_cont_time;  //Phase Bias has no distcontinuity within last X seconds.
}GPP_OCB_SATPHASE_BIAS, *pGPP_OCB_SATPHASE_BIAS;

typedef struct GPP_OCB_SATCODE_BIAS
{
	GPPDOUBLE time_since_last_iode; //Time Since Last Iode Change(in sec.)
	GPPDOUBLE User_range_error;      //User Change Error
}GPP_OCB_SATCODE_BIAS, *pGPP_OCB_SATCODE_BIAS;

/*typedef struct GPP_OCB_COMMON_INFO
{
 int gps_week;
 double sec_of_week;
 int system_id; //(SF 006)
 int system_processor_id; //(SF 007)
 int solution_id; //(SF 005)
 bool sat_ref_datum;//(SF 009)
 bool yaw_encode_flag;
 bool em_type;
 pGPP_OCB_SATELLITE_DATA satellite_data;
 pGPP_OCB_SATPHASE_BIAS phase_bias[3];
 pGPP_OCB_SATCODE_BIAS   code_bias[3];
}GPP_OCB_COMMON_INFO,*pGPP_OCB_COMMON_INFO;*/




/******************************************************************************
 *  \brief Write SAPA OCB content to buffer
 *
 *  \param[in]  ocb     Pointer to GPP_SAPA_OCB structure
 *  \param[in]  *buffer Pointer to buffer
 *  \param[in]  *byte_pos
 *  \param[in]  *bit_pos
 *
 *  \retval  needed bits (>0) or error code (<0)

 *****************************************************************************/
GPPLONG gpp_sapa_ocb2buffer(const pGPP_SAPA_OCB ocb, GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos);
GPPLONG gpp_sapa_buffer2ocb(pGPP_SAPA_OCB ocb, const GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos);

GPPLONG gpp_sapa_hpac2buffer(const pGPP_SAPA_HPAC hpac, GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos);
GPPLONG gpp_sapa_buffer2hpac(pGPP_SAPA_HPAC hpac, const GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos);

GPPLONG gpp_sapa_area2buffer(const pGPP_SAPA_AREA area, GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos);
GPPLONG gpp_sapa_buffer2area(pGPP_SAPA_AREA area, const GPPUCHAR *buffer, GPPLONG *byte_pos, GPPLONG *bit_pos);



#endif // GPP_SAPA_H
