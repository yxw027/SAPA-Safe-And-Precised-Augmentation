#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "gpp_sapa.h"
#include "compiler.h"

 char *sapa_gnf_nxt_token( char *string, char **nxt)
{
    char *result = NULL;
	while (string && *string && ((*string == ' ') || (*string == '\t')))
	{ 
		*string = '\0'; 
		string++;
	}	// Skip leading White Space
	if (string && *string)
	{
		char c = *string;
		char quote = '\0';
		result = string;
		if ((c == '"') || (c == '\'')) 
		{
			quote = c;
			*string = '\0'; // Delete the quote character
			string++;
			c = *string;
			result = string;
		}
		/* Suche Ende des Tokens (d.h. neaechstes Komma, "*", "\r" oder "\0") */
		while (1)
		{
			if (c && c == quote)
			{	                 
				*string = '\0'; // Delete the Quote Charatcer
				quote = '\0';
				string++;
				c = *string;
				continue;
			}
			if (quote)
			{
				if (c == '\0')
				{
					*nxt = NULL;
					return(result);
				}
				else
				{
					string++;
					c = *string;
					continue;
				}
			}
			switch (c)
			{
			case ',':
				*string = '\0';
				*nxt = string + 1;
				return(result);
			case '=':
				*string = '\0';
				*nxt = string + 1;
				return(result);
			case '\r':
				*string = '\0';
				*nxt = NULL;
				return(result);
			case ' ':
				*string = '\0';
				*nxt = string + 1;
				return(result);

			case '\0':
				*nxt = NULL;
				return(result);
			default:
				string++;
				c = *string;
				break;
			}
		}
	}
	else {
		*nxt = NULL;
		result = NULL;
	}
	return(result);
} /* gnf_nxt_token() */

 int sapa_split_arg_to_tokens( char *arg,  char ***tokens)
{
	char seprators[] = " " ",";
	char *nxt = arg;
	char *token=NULL;
	if (!*tokens)
	{
		//*tokens = strtok_s(nxt, seprators, &token);
		while (*tokens != NULL)
		{
			token = sapa_gnf_nxt_token(nxt, &nxt);
			//*tokens = strtok_s(NULL, seprators, &token);
		}
	}
	return(sizeof(*tokens));
}//sapa_split_arg_to_tokens()

 void sapa_read_ocb_ascii()
 {
	 FILE *pAsciiDataset = NULL; // file pointer to ASCII file containing datasets

	 char *line_buffer = NULL; // Read ASCII file line by line and store in this buffer
	 char **tokens = NULL;  // Store the tokens of the line read from the ASCII file
	 pAsciiDataset = fopen("ascii/SapaInteropTestDataset_001.ocb", "r");
	 if (pAsciiDataset)
	 {
		 //Allocate memory for line_buffer
		 line_buffer = (char*)calloc(256, sizeof(char)); //Assuming Max  character of line is 255
		 while (fgets(line_buffer, 256, pAsciiDataset))
		 {
		 	printf("%s\n", line_buffer);
			
		 }//while ends
		 if (line_buffer)
		 {
			 free(line_buffer);
		 }
	 }//fopen ends
	 else
	 {
		 printf("%s", "The file could not be opened");
	 }//else ends
 }
